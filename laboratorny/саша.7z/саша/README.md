# We Design and Develop (HTML шаблон сайта)
Шаблон We Design and Develop написан с использованием flexbox (в основе Bootstrap 4). 
Присутствует адаптивная верстка. 
Шаблон прошел валидацию.
Страница 1.

В процессе создания был использован бесплатный PSD шаблон, который взят [т-у-т](http://psd-html-css.ru/templates/piroll-besplatnyy-psd-shablon-dlya-portfolio)

## Было использовано:

##### Языки:
- HTML 5
- CSS 3
- JavaScript (ECMAScript)

##### Фреймворки:
- Bootstrap 4.1.3
- Owl Carousel 2.3.4

##### А также: 
- Bower - Менеджер пакетов
- Gulp - Таск-менеджер
- Git - Система управления версиями
- Sass - Препроцессор
- Jquery 3.3.1 - библиотека JavaScript
